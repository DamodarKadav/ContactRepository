Create Database ContactDB
GO

USE ContactDB
GO

CREATE TABLE dbo.Contacts
(
ID int primary key identity,
FirstName varchar(50),
LastName varchar(50),
Email varchar(50),
PhoneNumber bigint,
[Status] int
)

GO

Insert into dbo.Contacts values('Manish','Ranjan','Manish.Ranjan@gmail.com',5462354321,0)

