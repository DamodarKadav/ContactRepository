﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using ContactsDataAccess;
using System.Net.Http;
using System.Net;
using System.Web.Http;

namespace ContactManager.Services
{
    public class ContactRepository
    {

        /// <summary>
        /// Method for all contact details
        /// </summary>
        /// <returns>IEnumerable<Contact></returns>
        public IEnumerable<Contact> GetAllContacts()
        {            
            using(ContactDBEntities entities =new ContactDBEntities())
            {
                 return entities.Contacts.ToList();
            }
           
        }


        /// <summary>
        /// Method for contact details of particular ID
        /// </summary>
        /// <param name="ID">ID</param>
        /// <returns>Contact</returns>
        public Contact GetContact(int ID)
        {
            using (ContactDBEntities entities = new ContactDBEntities())
            {
                return entities.Contacts.FirstOrDefault(c=>c.ID==ID);
            }

        }

        /// <summary>
        /// Method for adding new contact details
        /// </summary>
        /// <param name="contact">Contact</param>
        /// <returns>bool</returns>     
        public bool AddContact(Contact contact)
        {
            using (ContactDBEntities entities = new ContactDBEntities())
            {
                entities.Contacts.Add(contact);
                entities.SaveChanges();
            }
                return true;
        }
        /// <summary>
        /// Method for deleting contact details for particular ID
        /// </summary>
        /// <param name="ID">ID</param>
        /// <returns>HttpStatusCode</returns>
        public HttpStatusCode DeleteContact(int ID)
        {

            using (ContactDBEntities entities = new ContactDBEntities())
            {
                var entity = entities.Contacts.FirstOrDefault(c => c.ID == ID);
                if (entity == null)
                {
                    return HttpStatusCode.NotFound;                    
                }
                else 
                { 
                entities.Contacts.Remove(entity);
                entities.SaveChanges();
                return HttpStatusCode.OK;
                }
            }
         
        }
        /// <summary>
        /// Method for editing contact details for particular ID
        /// </summary>
        /// <param name="ID">ID</param>
        /// <param name="contact">Contact</param>
        /// <returns>HttpStatusCode</returns>
        public HttpStatusCode EditContact(int ID, Contact contact)
        {
            using (ContactDBEntities entities = new ContactDBEntities())
            {
                var entity = entities.Contacts.FirstOrDefault(c => c.ID == ID);
                if (entity == null)
                {
                    return HttpStatusCode.NotFound;
                }
                else {
                entity.FirstName = contact.FirstName;
                entity.LastName = contact.LastName;
                entity.Email = contact.Email;
                entity.PhoneNumber = contact.PhoneNumber;
                entity.Status = contact.Status;
                entities.SaveChanges();
                return HttpStatusCode.OK;
                }
            }
            
        }

       
        
    }
}