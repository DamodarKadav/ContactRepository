﻿using ContactManager.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using ContactsDataAccess;

namespace ContactManager.Controllers
{
    public class ContactController : ApiController
    {
        private ContactRepository contactRepository;
        
        public ContactController()
        {
            this.contactRepository = new ContactRepository();
        }
        /// <summary>
        /// Method for all contact details
        /// </summary>
        /// <returns>IEnumerable<Contact></returns>
        [HttpGet]
        public IEnumerable<Contact> ListAllContacts()
        {
            try
            {
                return contactRepository.GetAllContacts();

            }
            catch (Exception ex)
            {
                return null;
            }
        }
        /// <summary>
        /// Method for contact details of particular ID
        /// </summary>
        /// <param name="ID">ID</param>
        /// <returns>Contact</returns>
        [HttpGet]
        public Contact ListContact(int ID)
        {
            try
            {
                return contactRepository.GetContact(ID);

            }
            catch (Exception ex)
            {
                return null;
            }
        }
        /// <summary>
        /// Method for adding new contact details
        /// </summary>
        /// <param name="contact">Contact</param>
        /// <returns>bool</returns>
        [HttpPost]
        public bool AddContact(Contact contact)
        {
            try
            {
                return contactRepository.AddContact(contact);
            }
            catch(Exception ex)
            {
                return false;
            }
        }
        /// <summary>
        /// Method for deleting contact details for particular ID
        /// </summary>
        /// <param name="ID">ID</param>
        /// <returns>HttpResponseMessage</returns>
        [HttpPost]
        public HttpResponseMessage DeleteContact(int ID)
        {
            try
            {
                HttpStatusCode statuscode= contactRepository.DeleteContact(ID);
                if (statuscode==HttpStatusCode.NotFound)
                {
                    return Request.CreateErrorResponse(statuscode, "Contact cannot be found.");
                }
                else 
                {
                    return Request.CreateResponse(statuscode);
                }
                              
            }
            catch (Exception ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex);
            }
        }
        /// <summary>
        /// Method for editing contact details for particular ID
        /// </summary>
        /// <param name="ID">ID</param>
        /// <param name="contact">Contact</param>
        /// <returns>HttpResponseMessage</returns>
        [HttpPost]
        public HttpResponseMessage EditContact(int ID, Contact contact)
        {
            try
            {
                HttpStatusCode statuscode = contactRepository.EditContact(ID,contact);
                if (statuscode == HttpStatusCode.NotFound)
                {
                    return Request.CreateErrorResponse(statuscode, "Contact cannot be found.");
                }
                else
                {
                    return Request.CreateResponse(statuscode);
                }
                
            }
            catch (Exception ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex);
            }
        }
    }
}
